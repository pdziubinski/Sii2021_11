package main;

public class Car {
	String vin;

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	@Override
	public String toString() {
		return "Car [" + (vin != null ? "vin=" + vin : "") + "]";
	}
	
	
}
