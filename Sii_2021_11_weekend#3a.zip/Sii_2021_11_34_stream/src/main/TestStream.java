package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.*;

public class TestStream {

	public static void main(String[] args) {
		Integer[] iT = { 1, 2, 3, 4, 5, 3, 4, 6, 7, 8, 2, 5, 9, 8, 2, 3 };
		List<Integer> l = new ArrayList<>(Arrays.asList(iT));
		Stream<Integer> str = l.stream();

		str = Stream.of(iT);

		long count = str.distinct().count();
		System.out.println(count);

		Stream<Integer> st1 = Stream.iterate(0, n -> n + 2).limit(21);

		Stream<Car> stCar = Stream.generate(() -> new Car()).limit(30);
		List<Car> lCar = new ArrayList<>();
		stCar.forEach((c) -> {
			c.setVin("WJS" + ((int) (Math.random() * 99999)));
			lCar.add(c);
//			return c;
		});

//		stCar.peek(lCar::add);

		for (Car car : lCar) {
			System.out.println(car.toString());
		}
		
		
	    List<Car> lcar = Stream
	            .generate(()-> new Car())
	            .limit(20)
	            .peek(System.out::println)
	            .collect(Collectors.toList());
	    
	    //4,Type.Sedan,4

for (Car car : lcar) {
	System.out.println(car.toString());
}
	}

}
