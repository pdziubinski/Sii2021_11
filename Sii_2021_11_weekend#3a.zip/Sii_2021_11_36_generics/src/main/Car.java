package main;

import model.Para;

public class Car {
	private Para p;

	public Para getP() {
		return p;
	}

	public void setP(Para p) {
		this.p = p;
	}

	
	
}
