package main;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.reflect.*;


import model.*;
public class TestGenerics {

	public static void main(String[] args) {
	
//		Para<Integer, String> p = new Para(1, "abc"); 
//		
//		Para<String, Car> p1 = new Para("Opel", new Car());
//		
//		Map<String, Car> m = new HashMap<>();
//		
//		System.out.println(p1.toString());
//		System.out.println(p.toString());
//		
//		p1.setFirst("a");

	     Para<String, Integer> p1 = new Para<String, Integer>("Ala", 3);
	     System.out.println(p1.getNr());
	     Para<String, Integer> p2 = new Para<String, Integer>("Ala", 1);
	     System.out.println(p2.getNr());
	     Para<String, String> p3 = new Para<String, String>("Ala", "Kowalska");
	     System.out.println(p3.getNr());

	     // Co jest - tylko klasa Para "Raw Type"

	     Class p1Class = p1.getClass();
	     System.out.println(p1Class);
	     Class p2Class = p2.getClass();
	     System.out.println(p2Class);
	     Class p3Class = p3.getClass();
	     System.out.println(p3Class);

	     	// Metodami refleksji mo�emy si� przekona�, �e w definicji klasy Para typem fazy wykonania 
	     	// dla parametr�w jest Object
	     	// TU DZIA�A "type erasure"     !!!

	     Method[] mets = p1Class.getDeclaredMethods();  // zwraca tablic� metod deklarowanych w klasie
	     for (Method m : mets) System.out.println(m);
	     Method[] mets3 = p3Class.getDeclaredMethods();  // zwraca tablic� metod deklarowanych w klasie
	     for (Method m : mets3) System.out.println(m);

	     // Surowego typu ("Raw Type") mo�emy te� u�ywa�
	     // ale czasem kompilator mo�e nas ostrzega� o mo�liwych b��dach


	     Para p = new Para("B", 3.1);
	     String f = (String) p.getFirst();
	     double d = (Double) p.getSecond();
	     System.out.println(f + " " + d);

	     List l = new ArrayList<>();
	     l.add("aaa");
	     l.add(new Car());
	     
	     String s = (String) l.get(0);
	     Car c1 = (Car) l.get(1);
	     
	     List<Car> l1 = new ArrayList();
	     
	     Para[] tt = new Para[5];
	     
	     tt[0] = p1;
	     tt[1] = p3;
	     
	     String[] res = new String[5];
	     
	     for (int i = 0; i < 2; i++) {
			res[i] = (String) tt[i].getSecond();
		}

	}

}
