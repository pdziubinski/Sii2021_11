
public class ParaChild extends Para {

	public ParaChild(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

	// "dziedziczenie" p�l i metod prywatnych przy u�yciu refleksji
}
