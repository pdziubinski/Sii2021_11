import java.lang.reflect.*;

public class Test {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
		Para p = new Para("asasa");
		
		System.out.println(p.getS());
		
		Class cls = p.getClass();
		System.out.println(cls.getName());
		
//		Constructor cntr = cls.getConstructor();
//		
//		System.out.println(cntr.getName());
		
		Method[] met = cls.getDeclaredMethods();
		for (Method method : met) {
			System.out.println(method.getName());
		}
		
		Method metS = cls.getDeclaredMethod("setS", String.class);
		metS.setAccessible(true);
		metS.invoke(p, "9485948594");
		System.out.println(p.getS());
		Field field = cls.getDeclaredField("s");
		field.setAccessible(true);
		
		field.set(p, "qwqewwqewewerw");
		
		System.out.println(p.getS());
		
		
	}

}
