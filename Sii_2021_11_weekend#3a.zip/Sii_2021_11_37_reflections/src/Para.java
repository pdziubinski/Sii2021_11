
public class Para {
	private String s;

	public Para(String s) {
		this.s = s;
	}

	public String getS() {
		return s;
	}

	private void setS(String s) {
		this.s = s;
	}
	
	
	
}
