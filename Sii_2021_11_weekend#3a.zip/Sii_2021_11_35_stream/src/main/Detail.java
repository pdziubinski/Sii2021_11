package main;

import java.util.ArrayList;
import java.util.List;

public class Detail {
	List<String> parts;
	int value;
	List<Integer> valList;
	
	Detail(){
		this.parts = new ArrayList<String>();
		this.valList = new ArrayList<Integer>();
	}

	public List<String> getParts() {
		return parts;
	}

	public List<Integer> getValues() {
		return valList;
	}
	public void setParts(List<String> parts) {
		this.parts = parts;
	}
	
	public List addParts(String part) {
		this.parts.add(part);
		return this.parts;
	}
	
	public List addValue(int i) {
		this.valList.add(i);
		return this.valList;
	}

	@Override
	public String toString() {
		return "Detail [" + (parts != null ? "parts=" + parts : "") + "]";
	}
	
	
}
