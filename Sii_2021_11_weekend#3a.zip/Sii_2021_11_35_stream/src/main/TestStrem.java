package main;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class TestStrem {

	public static void main(String[] args) {
		
		
		List<Detail> details = new ArrayList<>();
		Detail d1 = new Detail();
		d1.addValue(1);
		d1.addValue(7);
		d1.addValue(21);
		d1.addParts("asasa");
		d1.addParts("qwqw");
		d1.addParts("rttyyt");
		details.add(d1);
		Detail d2 = new Detail();
		d2.addParts("1212");
		d2.addParts("3434");
		d2.addParts("575");
		d2.value = 15;
		d1.addValue(11);
		d1.addValue(72);
		d1.addValue(32);
		details.add(d2);	
		
		System.out.println(d1.toString());
		
		Stream<String> stream  = details.stream().flatMap(detail -> detail.getParts().stream());

		stream.forEach(System.out::println);
		
		Integer reduced = details.stream().map((e) -> e.value).reduce(0, (a, b) -> a +b);
		System.out.println(reduced);
		
		Integer reducedVal = details.stream().flatMap(e -> e.getValues().stream()).reduce(0, (a, b) -> a +b);
		System.out.println(reducedVal);
	}

}
