package main;


class Date {
	int year;
	int month;
	int day;
	public Date(int year, int month, int day) {
		this.year = year;
		this.month = month;
		this.day = day;
	}
	
}



public class Test {

	public static void main(String[] args) {
		Date date = new Date (1999, 10, 24) ; 
		changeVal (date);
		System.out.println (date.day); 

	}

	private static void changeVal(Date val) {
		 val.day = 10; 
	}

}
