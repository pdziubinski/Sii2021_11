import java.io.*;
import java.net.*;

public class WebReader {
	public static void main(String[] args) {
		try {
			// url z adresem strony	
			URL url = new URL ("https://www.nbp.pl/xml/stopy_procentowe.xml");
			
			// strumien do odczytu danych
			BufferedReader in = new BufferedReader (
							new InputStreamReader(url.openStream())); 
			FileWriter fw = new FileWriter ("stopy_procentowe.xml");
			String str;
			while ((str = in.readLine()) != null) {
				// operacje na pojedynczych wierszach zwroconych danych
//				System.out.println(str);
				fw.write(str + "\n");

			}
			try{ 
				fw.close();
				in.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			;
		   } catch (MalformedURLException e) {
			e.printStackTrace();
		   } catch (IOException e) {
			e.printStackTrace();
		   }

       }
}

