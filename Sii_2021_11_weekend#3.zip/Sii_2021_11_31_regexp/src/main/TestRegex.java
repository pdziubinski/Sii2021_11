package main;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestRegex {

	public static void main(String[] args) {
		String pat = "^([A-Za-z]{2})*[\\s]*[0-9]{2}[\\s]*([0-9]{4}[\\s]*){6}$";
		String ibanAccNum1 = "PL01 12401234 0000 1111 2222 3333";
		String ibanAccNum1a = "Pl01 12401234 0000 1111 2222 3333";
		String ibanAccNum2 = "01 12401234 0000 1111 2222 3333";
		String ibanAccNum3 = "011240123400001111222233331";  // tu jest 27 cyfr
		
		List<String> accList = new ArrayList<String>();
		accList.add(ibanAccNum1);
		accList.add(ibanAccNum1a);
		accList.add(ibanAccNum2);
		accList.add(ibanAccNum3);
		
//		for (String acc : accList) {
//			System.out.printf("Konto nr %s jest %s\n", acc, checkAcc(acc, pat)?"poprawne":"niepoprawne");
//		}
		
		accList.forEach((strAcc) -> System.out.printf("Konto nr %s jest %s\n", strAcc, checkPat(strAcc, pat)?"poprawne":"niepoprawne"));
		

		String tel = "345123098";
		System.out.println(checkPat(tel, "^[\\d]{9}$"));
	}
	
	public static boolean checkPat(String s, String pattern) {
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(s);
		boolean b = m.matches();
		return b;
	}

}
