public class ExampleBAD {
	public String zmienna = "cos";

	public static void main(String args[]){
		
		ExampleBAD e = new ExampleBAD();
		System.out.println("B��d kompilacji:" + e.zmienna);
		
		boolean b = false;
		if(b = true) {
			System.out.println("Tu jestem");
		}
		
		
		String s1 = "abc";
		String s2 = "abc";
		s1 = null;
		
//		System.out.println(s1.equals(s2));
		
		if (s1 == null) {
			System.out.println("TO jest null");
		}
		

		
		if ((s1 == null)?true:s1.equals(s2)) {
			System.out.println("Naprawd� jest OK");
		}
		
		if (s1.equals(s2)){
			System.out.println("Niby jest OK");
		}
		
		String stxt = "abc";
		
		print(stxt);
		System.out.println("A tu " + stxt);
		
		Integer i = 10;
		print(i);
		System.out.println("Po powrocie i=" + i);
		
		Car c = new Car("abc");
		System.out.println("Przed:"+c.getTxt());
		print(c);
		System.out.println("Po:" +c.getTxt());
		
		
	}

	private static void print(Car c) {
		c.setTxt("xyz");
		System.out.println("wewn�trz:" +c.getTxt());
		
	}

	private static void print(Integer i) {
		 i = 15;
		 System.out.println("i="+i);
		
	}

	private static void print(String stxt) {

		stxt = "qwerty";
		System.out.println("Tu stxt jest "+ stxt);
		
	}
	
	
}
