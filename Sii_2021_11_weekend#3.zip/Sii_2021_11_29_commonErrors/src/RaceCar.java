
public class RaceCar extends Car {
	boolean engineIsOn;
	
	public RaceCar(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}

	public boolean isEngineIsOn() {
		return engineIsOn;
	}

	public void setEngineIsOn(boolean engineIsOn) {
		this.engineIsOn = engineIsOn;
	}

	

}
