
public class Car {
	private String txt;
	
	public Car(String string) {
		this.txt = string;
	}
	public String getTxt() {
		return txt;
	}
	public void setTxt(String txt) {
		this.txt = txt;
	}
	

}
