package main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		List<String> lSt = new ArrayList();
		
		lSt.add("asds");
		lSt.add("dsfef");
		lSt.add("aasdf");
		lSt.add("asew23ds");
		lSt.add("12aw");
		
		for (String string : lSt) {
			System.out.println(string);
		}
		System.out.println("-----------------");
		
		Collections.sort(lSt);
		for (String string : lSt) {
			System.out.println(string);
		}	
		
		List<Integer> lIn = new ArrayList<Integer>(100000);
		Collections.fill(lIn, 15);

	}

}
