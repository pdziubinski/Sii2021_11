import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class TimerSample {
	public static void main(String[] args) {
		final int delayInMiliseconds = 15000;
		System.out.printf("Moment wyznaczenia zadania: %tT%n", new Date(System.currentTimeMillis()));
		Date timeToRun = new Date (
							System.currentTimeMillis() + delayInMiliseconds);
		Timer timer = new Timer ();
		timer.schedule(new TimerTask() {	 
							@Override
							public void run() {
								System.out.printf("Moment wykonania zadania: %tT%n", new Date(System.currentTimeMillis()));
								
							}
						}, timeToRun);
	}
}
