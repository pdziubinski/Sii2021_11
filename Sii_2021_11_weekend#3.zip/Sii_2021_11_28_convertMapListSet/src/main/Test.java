package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

public class Test {

	public static void main(String[] args) {
		
		Car[] c = new Car[10];
		
		for (int i = 0; i < c.length; i++) {
			c[i] = new Car("qwe" + i, "black", new Engine());
		}
		
		List<Car> l = new ArrayList(Arrays.asList(c));
		
		Map<String, Car> m  = new HashMap<String, Car>();
		
		for (Car c1 : l) {
			m.put(c1.getVin(), c1);
		}
		
		List<Car> l2 = new ArrayList<Car>(m.values());
		
		Set<String> s = new HashSet<String>(m.keySet());
		int lp = 1;
		for (String stringVin : s) {
//			System.out.println("VIN pojazdu: " + stringVin);
			System.out.printf("%d. VIN pojazdu: %s\n", lp++, stringVin);
			System.out.println(lp++ + ". VIN pojazdu: "+ stringVin);
//			System.out.printf("VIN pojazdu: %d\n", lp++);
		}
		// %b true/false    %B TRUE/FALSE
		for (Car car : l2) {
			System.out.printf("%d. VIN pojazdu: %S, moc silnika: %f\n", lp++, car.getVin(), car.getE().power);
		}
		
		Date date = new Date();
		System.out.printf("%tT%n", date);
		System.out.printf("godzina %tH, minuty %tM, sekundy %tS %n", date, date, date);
		
		System.out.printf("%1$tz%n", date);
		System.out.printf("%1$tA%n", date);
		System.out.printf("%1$td %1$tB%n", date, date);
		System.out.printf("%1$tY%n", date);
		
		// td - dzie�,    tm - miesi�c,    ty - rok
		System.out.printf("%1$td/%1$tm/%1$ty\n", date);
		
		System.out.println(Integer.toHexString(37364));
		System.out.println(Integer.toBinaryString(Float.floatToIntBits(10.15f)));
		System.out.println(Long.toBinaryString(Double.doubleToLongBits(10.15)));
		
		List<String> txtList = new ArrayList<String>();
		String txt = "abc|wsc|wert|hfvg";
		StringTokenizer st = new StringTokenizer(txt, "|");
		while(st.hasMoreTokens()) {
//			System.out.println(st.nextToken());
			txtList.add(st.nextToken());
		}
		
		for (String stx : txtList) {
			System.out.println(stx);
		}
	}

}
