package main;

public class Car {
	String vin;
	String color;
	Engine e;
	
	
	public Car(String vin, String color, Engine e) {
		this.vin = vin;
		this.color = color;
		this.e = e;
	}
	
	public String getVin() {
		return vin;
	}
	public String getColor() {
		return color;
	}
	public Engine getE() {
		return e;
	}
	
	
}
