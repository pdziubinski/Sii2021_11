package main;

public class Engine {
	float power;
	float volume;
	String type;
	
	Engine (){
		this.power = 100.0f;
		this.volume = 1997.0f;
		this.type = "SD32F4";
	}
}
