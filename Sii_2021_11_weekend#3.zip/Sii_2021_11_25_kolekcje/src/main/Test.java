package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

public class Test {

	public static void main(String[] args) {
		
		List<Car> l = new LinkedList<>();
		
		for (int i = 99; i >=0; i--) {
			l.add(new Car("" + i));
		}
		
		l.remove(50);
		
		System.out.println(l.size());
		
		l.add(new Car("" + 1000));
		
		l.add(null);
		l.add(null);
		
		for (Car car : l) {
			if(car != null) {
			System.out.println(car.toString());
			}
		}
		
//		for (Iterator it = l.iterator(); it.hasNext();) {
//			if(it.next() != null ) {
//				System.out.println(((Car) it.next()).toString());
//			}
//		}
		
		Map<String, Car> m = new TreeMap<>();
		for (Car car : l) {
			if (car != null) {
				m.put(car.getVin(), car);
			}
		}
		
		System.out.println(m.get("WJX34"));
		
		for (Entry e : m.entrySet()) {
			System.out.println(e.getKey() + ": " +e.getValue().toString());
		}
		
		
		Map<String, Object> map = new HashMap<>();
		
		map.put("1", new Car("WJX1001"));
		
		map.put("11", "abc");
		
		for(Entry e: map.entrySet()) {
			System.out.println(e.getValue().toString());
		}
		
		
		List parrots = new ArrayList();
		
		
		

	}

}
