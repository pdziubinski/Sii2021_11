package main;

public class Car {
	String vin;

	public Car(String vin) {
		this.vin = "WJX" + vin;
	}
	
	

	public String getVin() {
		return vin;
	}



	@Override
	public String toString() {
		return "Car [" + (vin != null ? "vin=" + vin : "") + "]";
	}
	
	

}
