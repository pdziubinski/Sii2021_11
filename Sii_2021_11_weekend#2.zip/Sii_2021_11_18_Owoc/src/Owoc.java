
public class Owoc {
	
	private int waga = 0;
	
	String nazywamSie() {
		return this.getClass().getSimpleName();
	}
	
	
	public float getWaga() {
		return waga;
	}


	class Skorka{
		float grubosc;
		
		void setWaga(int w){
			waga = w;
		}
	}
}
