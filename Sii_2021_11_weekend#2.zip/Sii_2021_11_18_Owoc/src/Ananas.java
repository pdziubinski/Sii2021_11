
public class Ananas extends Owoc {

}
