
public class Gruszka extends Owoc {

//	@Override
//	String nazywamSie() {
//		// TODO Auto-generated method stub
//		return super.nazywamSie() + " Gruszka";
//	}
	public String getIloscCukru() {
		return "du�o";
	}

}
