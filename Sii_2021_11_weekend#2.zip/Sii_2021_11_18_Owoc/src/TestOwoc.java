

public class TestOwoc {

	public static void main(String[] args) {
//		JablkoAntonowka ja = new JablkoAntonowka();
//		System.out.println(ja.nazywamSie());
//		
//		
//		Jablko j = new Jablko();
//		j.new Skorka().setWaga(1);
//		
//		System.out.println(j.getWaga());
//		
//		Owoc o = new Owoc();
//		o.new Skorka().setWaga(2);
//		
//		System.out.println(o.getWaga());
		
//		ja.waga = 12.3;
//		
//		
//		Owoc o = new Owoc();
//		o.new Skorka().grubosc = 1.11f;
//		
//		Jablko j = new Jablko();
//		
//		j.
//		j.new Skorka().grubosc = 2.15f;
		
		Owoc owoc;
		owoc = new Gruszka();
		System.out.println(owoc.nazywamSie()); 
		owoc = new JablkoAntonowka(); 
		System.out.println(owoc.nazywamSie()); 
		
		
		Owoc[] owocT = new Owoc[30];
		for (int i = 0; i < 10; i++) {
			owocT[i] = new Jablko();
		}
		for (int i = 10; i < 20; i++) {
			owocT[i] = new JablkoAntonowka();
		}		
		for (int i = 20; i < 30; i++) {
			owocT[i] = new Gruszka();
		}
		
		for (Owoc o : owocT) {
			wydrukuj(o);
			if (o instanceof Gruszka) {
				System.out.println(((Gruszka) o).getIloscCukru());
			}
		}
		
		
		Ananas a = new Ananas();
		wydrukuj(a);
		
		
		float f = 1.2f;
		
		int g = (byte) f;
		System.out.println(g);
		
	}
	
	static void wydrukuj(Owoc o) {
		System.out.println(o.nazywamSie());
	}

}
