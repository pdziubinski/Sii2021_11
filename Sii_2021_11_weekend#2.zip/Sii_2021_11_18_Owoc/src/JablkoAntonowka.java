
public class JablkoAntonowka extends Jablko{

	double waga;
	
//	@Override
//	String nazywamSie() {
//		// TODO Auto-generated method stub
//		return super.nazywamSie() + "Antonowka";
//	}
	
	
	
}
