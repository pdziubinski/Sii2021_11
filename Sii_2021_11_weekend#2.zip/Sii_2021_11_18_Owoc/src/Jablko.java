
public class Jablko extends Owoc{

	private float waga;
	
//	@Override
//	String nazywamSie() {
//		return "Jablko";
//	}

	
	public float getWaga() {
		return waga;
	}
	
	
}
