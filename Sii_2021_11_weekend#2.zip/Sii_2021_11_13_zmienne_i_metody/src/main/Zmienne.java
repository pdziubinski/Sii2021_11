package main;

public class Zmienne {
	private int a;
	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	float b;
	String s;
	
	int metoda() {
		int a = 7;
//		System.out.println(a);
		
//		this.a = a;
		return a;
	}
	
	boolean isValid() {
		return this.a == 0? false:true;
	}
	
	
}
