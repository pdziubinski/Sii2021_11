package main;

public class Test {

	public static void main(String[] args) {
//		Zmienne z = new Zmienne();
////		z.a = 0;
//		System.out.println(z.metoda());
//		
//		z.setA(z.metoda());
//		System.out.println(z.getA());
		
		
//		int x = 7;
//		int y = 5;
//		
//		if(++x == 8 && --y == 4) {
//			System.out.println("PRAWDA");
//		}
//		
//		System.out.println(y);
		
//		Zmienne z = new Zmienne();
//		if(z.isValid()) {
//			System.out.println("operacja sprawdzenia");
//		}
//		
//		Zmienne z2 = null;
//		if(z2 != null && z2.isValid()) {
//			System.out.println("operacja sprawdzenia");
//		}
//		
//		
//		int x = 17;
//		System.out.println(x<<4);
//		System.out.println(x*16);
		
		int q = 19;
		int res = 0;
		for (int i = 0; i < Integer.MAX_VALUE; i++) {
			res = q>>1;
//			res = q*2;
		}
		System.out.println(res);
		
		System.out.println(~19);
	}

}
