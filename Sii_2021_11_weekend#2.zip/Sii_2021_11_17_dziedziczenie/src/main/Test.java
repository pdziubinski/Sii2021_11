package main;

public class Test {

	public static void main(String[] args) {
		Truck t = new Truck(12, "dfdfd", new Engine("SW34E"), 24000);
		System.out.println(t.toString());

	}

}
