package main;

public class Engine {
	String engineType;

	public Engine(String engineType) {
		this.engineType = engineType;
		System.out.println("Konstruktor nr 5: Engine(String engineType)");
	}
	
	
}
