package main;

public class Truck extends Car{

	private int load;
	
	public Truck(int wheelsAmount, String vin, Engine e) {
		super(wheelsAmount, vin, e);
		System.out.println("Konstruktor nr 3: Truck(int wheelsAmount, String vin, Engine e)");
	}

	public Truck(int wheelsAmount, String vin, Engine e, int load) {
		this(wheelsAmount, vin, e);
		this.load = load;
		System.out.println("Konstruktor nr 4: Truck(int wheelsAmount, String vin, Engine e, int load)");
	}
	
	
	

}
