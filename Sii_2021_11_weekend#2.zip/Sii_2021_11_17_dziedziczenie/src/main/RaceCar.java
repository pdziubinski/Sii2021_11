package main;

public class RaceCar extends Car{

	public RaceCar(String vin) {
		super(vin);
		// TODO Auto-generated constructor stub
	}

}
