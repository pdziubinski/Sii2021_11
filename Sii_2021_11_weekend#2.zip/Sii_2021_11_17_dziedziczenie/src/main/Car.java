package main;

public class Car {
	private int wheelsAmount;
	private String vin;
	private Engine e;
	
	
	
	public Car(String vin) {
		this.vin = vin;
		System.out.println("Konstruktor nr 1: Car(String vin)");
	}

	public Car(int wheelsAmount, String vin, Engine e) {
		this(vin);
		this.wheelsAmount = wheelsAmount;
		this.e = e;
		System.out.println("Konstruktor nr 2: Car(int wheelsAmount, String vin, Engine e)");
	}

	@Override
	public String toString() {
		return "Car [wheelsAmount=" + wheelsAmount + ", " + (vin != null ? "vin=" + vin + ", " : "")
				+ (e != null ? "e=" + e : "") + "]";
	}
	
	
	
}
