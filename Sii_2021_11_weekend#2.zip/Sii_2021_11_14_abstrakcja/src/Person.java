
public interface Person {
	void changeName(String name, String surname);
	void makeOrder(String s);
}
