
public class Test {

	public static void main(String[] args) {
		Klient k = new Klient();
		
		k.changeName("Jan", "Zielinski");
		k.setAccountActive();
		AccountMethods.setAccountInactive();

	}

}
