
public interface AccountMethods {
	boolean isAccountActive();
	
	default boolean setAccountActive() {
		int acc =100;
		return true;
	}
	
	static boolean setAccountInactive() {
		int acc =100;
		return false;
	}
}
