
public class Klient extends Client implements Person, AccountMethods{

	@Override
	public void doTransfer(double transferAmount, Client k) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void makeOrder(String s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeName(String name, String surname) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isAccountActive() {
		// TODO Auto-generated method stub
		return false;
	}

}
