
public class Osoba {
	String name;
	String surname;
	String pesel;
	String sex;
	String cardID;
	
	void changeName(String name, String surname) {
		//
	}
		
}
