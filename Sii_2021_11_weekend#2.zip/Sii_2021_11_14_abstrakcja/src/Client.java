
public abstract class Client {
	String name;
	String accNumber;
	
	public abstract void doTransfer(double transferAmount, Client k);

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	
	
}
