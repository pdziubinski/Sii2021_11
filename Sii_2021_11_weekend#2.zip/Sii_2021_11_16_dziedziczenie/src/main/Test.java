package main;

import model.Administrator;

public class Test {

	public static void main(String[] args) {

		Administrator a = new Administrator();
		a.setResponsibility("administrowanie serwerami baz danych");
		
		a.setSalary(5000);
		a.method();
		
		System.out.println(a.toString());
		
//		Employee e = new Employee("Jan Kowalski", 4000);
////		e.setName("Jan Kowalski");
////		e.setSalary(4000);
//		System.out.println(e.toString());
	}

}
