package model;

public class Administrator extends Employee{
	String responsibility;
	
	
	public Administrator(){
		super("", 0);
	}

	public String getResponsibility() {
		return responsibility;
	}

	public void setResponsibility(String responsibility) {
		this.responsibility = responsibility;
	}
	
	public void method() {
//		this.salary = 7000;
//		super.setSalary(7000);
		this.setSalary(7000);
	}
	
	@Override
	public String toString() {
		return super.toString() + ", responsibility=" + this.responsibility;
	}
	
}
