package main;

public abstract class Osoba implements MetodyWspolne{
	
	String www = "aaa";
		
	abstract void dodajOsobe();
	
	void usunOsobe() {
		// tu implementacja
	}
	
}
