package main;

public class Pracownik extends Osoba {
	int k = 8;

	@Override
	void dodajOsobe() {
		int k = 9;
		
		
	}

	@Override
	public void metoda() {
		// TODO Auto-generated method stub
		
	}

}
