package main;

public interface MetodyWspolne {
	final String aaa = "sss";
	
	
	public void metoda();
	
	public default void met2() {
		
	}
}
