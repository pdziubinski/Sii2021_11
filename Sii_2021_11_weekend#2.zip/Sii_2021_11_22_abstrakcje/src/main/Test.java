package main;

public class Test {

	public static void main(String[] args) {

Osoba o = new Pracownik();
o.dodajOsobe();
System.out.println(o.aaa);

o.www = "itruirutir";
System.out.println(o.www);

	}

}
