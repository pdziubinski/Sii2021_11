public class Company {
	//zmienna trzymaj�ca referencje 
	private static Company instance;

	//prywatny konstruktor
	private Company() { /* � */ }

	//metoda zwracaj�ca referencje 
	public static Company getInstance() { 
	  if (instance == null) {
		instance = new Company();
	  }
	  return instance;
	}
 // inne, obiektowe sk�adniki klasy 
}
