
public class Test {
	public static final int TIMEOUT = 1000; 
	public static void main(String[] args) {
		Company myC = Company.getInstance();
		System.out.println(myC);
		
		Company otherC = Company.getInstance();
		System.out.println(otherC);
		
		final Employee e = new Employee("Kowalski", 5000, "developer");
		
		System.out.println(e.toString());
		
		e.salary = 7000;
		System.out.println(e.toString());
		
		final String s = "abc";
		System.out.println(s);
		
		final Employee[] eT = new Employee[10];
		
		eT[0] = new Employee("Nowak", 2000, "accountant");
		eT[1] = e;
		
		eT[1] = new Employee("Nowak", 5000, "accountant");
		
//		s = "abc";  //�le
//		
//		final Integer i = 13;
//		i =15;  //�le
//		
//		
//		final String s1 = new String("qwe");
//		s1 = "";  //�le
		
	}

}
