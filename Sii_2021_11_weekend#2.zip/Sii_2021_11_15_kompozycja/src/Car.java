
public class Car {
	Wheels[] w;

	public Car() {
		w = new Wheels[4];
		for (int i = 0; i < w.length; i++) {
			w[i] = new Wheels(15, new Tyre());
		}
		this.w = w;
		
	}
}
