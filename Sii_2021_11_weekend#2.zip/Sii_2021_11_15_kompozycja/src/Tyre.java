
public class Tyre {

}
