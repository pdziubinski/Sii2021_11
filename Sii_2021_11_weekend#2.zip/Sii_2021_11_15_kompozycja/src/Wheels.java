
public class Wheels {
	int radius;
	Tyre t;
	public Wheels(int radius, Tyre t) {
		this.radius = radius;
		this.t = t;
	}
	
	
}
