package main;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		StringBuffer sb = new StringBuffer();
		String s;
		while(true) {
			s = sc.next();
			if(s.equals("koniec")) break;
			sb.append(s);
		}
		
		System.out.println(sb.toString());
		
		Locale polska = new Locale ("pl", "PL");
		NumberFormat nf = NumberFormat.getCurrencyInstance(polska);
		Double pensja = 123456.78;
		System.out.println(nf.format(pensja));


	}

}
