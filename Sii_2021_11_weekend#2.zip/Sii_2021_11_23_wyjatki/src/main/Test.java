package main;

public class Test {

	public static void main(String[] args) {
		Obliczenia o = new ObliczeniaInt();
		double wynik;
		try {
			wynik = o.podziel(3, 0);
			System.out.println(wynik);
		} catch (MojWyjatek w) {
			System.out.println(w.getMessage());
		}
		  catch (Exception e) {
			e.printStackTrace();
		}

	}

}
