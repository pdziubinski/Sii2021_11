package main;

public class ObliczeniaInt extends Obliczenia {

	@Override
	public double podziel(double d, double g) throws ArithmeticException, Error, MojWyjatek {
		int f;
		if (g < 0.001) {
			g = 0;
//			throw new MojWyjatek("dzielenie przez zero");
		}
		int a = (int) d;
		int b = (int) g;
		
		try {
//		return d/g;
		return a/b;
		} catch (ArithmeticException e) {
			e.printStackTrace();
//			throw new MojWyjatek("dzielenie przez zero");
		}
		return a/b;
	
	}

}
