package main;

public class MojWyjatek extends Exception {
	
	MojWyjatek(){}
	
	MojWyjatek(String msg){
		super(msg);
	}
}
