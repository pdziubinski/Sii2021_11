package main;

public class Obliczenia {

	public double podziel(double d, double g) throws Exception {
		return d/g;
	}
}
