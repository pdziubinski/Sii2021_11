
public interface Metody {
	void met1();
	default void met2(int a) {
		a = a*2;
	}
	
	static int met3(int a, int c) {
		return a*c;
	}
}
