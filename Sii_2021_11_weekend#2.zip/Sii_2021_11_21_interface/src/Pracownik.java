
public class Pracownik extends Osoba {
	final int x = 7;
	private class Kolejarz{
		void print() {

		}
	}
	
	@Override
	public void met1() {
		final int a;
		
		a = 9;
		System.out.println(a);
		
		
		Kolejarz k = new Kolejarz();
		k.print();
		
	}

}



