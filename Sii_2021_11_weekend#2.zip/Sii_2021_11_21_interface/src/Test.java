
public class Test {

	public static void main(String[] args) {
		Pracownik p = new Pracownik();
		p.met1();
		
		
//		Kolejarz k = new Kolejarz();

	}

}
