
public abstract class Osoba implements Metody{
	String name;

	String getName() {
		return name;
	}

	void setName(String name) {
		this.name = name;
	}

	
	
}
