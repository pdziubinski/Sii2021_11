
class Speedster {
	static int numSpots;

	static public int getNumSpots() {
		return numSpots;
	}
	
}


public class Cheetah extends Speedster {
	int numSpots;
	
	public Cheetah(int numSpots) {
		super.numSpots = numSpots;
	}
	
//	@Override
//	public int getNumSpots() {
//		return numSpots;
//	}	

	public static void main(String[] args) {
		Speedster s = new Cheetah(50);
		Cheetah c = new Cheetah(50);
		System.out.println(s.numSpots);
		System.out.println(s.getNumSpots());
		System.out.println(c.numSpots);
		System.out.println(c.getNumSpots());
		
		Speedster s1 = new Speedster();
		System.out.println(s1.numSpots);
		
	Speedster[] sp= new Speedster[10000];
	for (int i = 0; i < 10; i++) {
		sp[i] = new Speedster();
	}	

	for (Speedster speedster : sp) {
		System.out.println(speedster.getNumSpots());
	}
	}

}
