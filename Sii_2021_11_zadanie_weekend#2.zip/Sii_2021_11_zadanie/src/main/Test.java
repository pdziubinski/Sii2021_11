package main;

import model.Student;
import model.Wydzial;

public class Test {
	public static void main(String[] args) {
		Wydzial w1 = new Wydzial("Elektryczny", 10);
		Wydzial w2 = new Wydzial("Mechaniczny", 15);
		
		Student s1 = new Student("Anna", "Kowalska", "01290112345");
		Student s2 = new Student("Jan", "Nowak", "02290101234");
		Student s3 = new Student("Karol", "Zielinski", "03290105671");
		Student s4 = new Student("Wojciech", "Zielinski", "03250103210");
		Student s5 = new Student("Marlena", "Zielinska", "03210101111");
		Student s6 = new Student("Marzena", "Kot", "03210101112");
		Student s7 = new Student("Jadwiga", "Kowal", "03210101113");
		Student s8 = new Student("Joanna", "Kowalik", "03210101114");
		Student s9 = new Student("Ada", "Zenek", "03210101115");
		Student s10 = new Student("Ida", "Krakowska", "03210101116");
		
		w1.addStudent(s1);
		w1.addStudent(s2);
		w2.addStudent(s3);
		w1.addStudent(s4);
		w1.addStudent(s5);
		w1.addStudent(s6);
		w1.addStudent(s7);
		w2.addStudent(s8);
		w2.addStudent(s9);
		w2.addStudent(s10);
		
		
		for (Student st : w1.getTabStudentow()) {
			if(st!= null) System.out.println(st.toString());
		}
		for (Student st : w2.getTabStudentow()) {
			if(st!= null) System.out.println(st.toString());
		}
		
		w1.removeStudent(s2);
		System.out.println("----------------------------------------------");
		for (Student st : w1.getTabStudentow()) {
			if(st!= null) System.out.println(st.toString());
		}
		w1.removeStudent(s7);
		System.out.println("----------------------------------------------");
		for (Student st : w1.getTabStudentow()) {
			if(st!= null) System.out.println(st.toString());
		}
		w2.removeStudent(s3);
		System.out.println("----------------------------------------------");
		for (Student st : w2.getTabStudentow()) {
			if(st!= null) System.out.println(st.toString());
		}
		
		
		w1.moveTo(w2, s1);
		System.out.println("-------------------moveTo---------------------------");
		for (Student st : w1.getTabStudentow()) {
			if(st!= null) System.out.println(st.toString());
		}
		for (Student st : w2.getTabStudentow()) {
			if(st!= null) System.out.println(st.toString());
		}
		
	}
}
