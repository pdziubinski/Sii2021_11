package model;

public class Student {
	private String imie;
	private String nazwisko;
	private String pesel;
	private String index;
	private Wydzial w;
	
	public Student(String imie, String nazwisko, String pesel) {
		this.imie = imie;
		this.nazwisko = nazwisko;
		this.pesel = pesel;
	}

	public String getImie() {
		return imie;
	}

	public String getNazwisko() {
		return nazwisko;
	}

	public void setNazwisko(String nazwisko) {
		this.nazwisko = nazwisko;
	}

	public String getPesel() {
		return pesel;
	}

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public Wydzial getW() {
		return w;
	}

	public void setW(Wydzial w) {
		this.w = w;
	}

	@Override
	public String toString() {
		return "Student [" + (imie != null ? "imie=" + imie + ", " : "")
				+ (nazwisko != null ? "nazwisko=" + nazwisko + ", " : "")
				+ (pesel != null ? "pesel=" + pesel + ", " : "") + (index != null ? "index=" + index + ", " : "")
				+ (w != null ? "w=" + w.getNazwaWydz() : "") + "]";
	}
	
	
}
