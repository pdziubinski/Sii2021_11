package model;

public class Wydzial {
	private Student[] tabStudentow;
	private String nazwaWydz;
	private int maxStudent;
	private int iloscStudentow = 0;
	
	
	
	public Wydzial(String nazwaWydz, int maxStudent) {
		this.nazwaWydz = nazwaWydz;
		this.maxStudent = maxStudent;
		this.tabStudentow = new Student[0];
	}
	
	public Student[] getTabStudentow() {
		return tabStudentow;
	}
	public void setTabStudentow(Student[] tabStudentow) {
		this.tabStudentow = tabStudentow;
	}
	public String getNazwaWydz() {
		return nazwaWydz;
	}
	public void setName(String nazwaWydz) {
		this.nazwaWydz = nazwaWydz;
	}
	
	public void setMaxStudent(int maxStudent) {
		this.maxStudent = maxStudent;
	}
	public int getMaxStudent() {
		return maxStudent;
	}
	
	public int getIloscStudentow() {
		return iloscStudentow;
	}

	public void setIloscStudentow(int iloscStudentow) {
		this.iloscStudentow = iloscStudentow;
	}

	public boolean addStudent(Student s) {
		if (getIloscStudentow() < getMaxStudent()) {
			Student[] tempSt = new Student[getIloscStudentow() + 1];  // new Student[5]
			System.arraycopy(this.tabStudentow, 0, tempSt, 0, getIloscStudentow());
			this.tabStudentow = tempSt;
			this.tabStudentow[getIloscStudentow()] = s;
			setIloscStudentow(this.tabStudentow.length);
			s.setW(this);
			return true;
		} else {
			return false;
		}
	}
	
	public boolean removeStudent(Student s) {
		boolean contains = false;
		for (int i = 0; i < this.tabStudentow.length; i++) {
			if (this.tabStudentow[i].getPesel() == s.getPesel()) {
				contains = true;
				Student[] tempSt = new Student[getIloscStudentow()-1];
				System.arraycopy(this.tabStudentow, 0, tempSt, 0, i);
				System.arraycopy(this.tabStudentow, i+1, tempSt, i, getIloscStudentow()-i-1);
				this.tabStudentow = tempSt;
				setIloscStudentow(this.tabStudentow.length);
				break;
			}
		}
		return contains;
	}

	public void moveTo(Wydzial w2, Student s) {
		this.removeStudent(s);
		w2.addStudent(s);
	}
	
	
	
}
